import pickle

def vrednost_pdv():
    try:
        pdv = float(input("Unesi pdv>>>"))
        return pdv
    except:
        print("Mora se uneti realna brojevna vrednost!")

def dodavanje_artikala(cenovnik):
    lista_za_jedan_artikal =[]
    lista_imena = []
    try:
        lista_za_jedan_artikal =[]
        ime_artikla = input("Unesi ime artikla>>>")
        opis_artikla = input("Unesi opis artikla>>>")
        cena_artikla = float(input("Unesi cenu>>>"))
        lista_imena.append(ime_artikla)
        lista_za_jedan_artikal.append(opis_artikla)
        lista_za_jedan_artikal.append(cena_artikla)
        cenovnik[ime_artikla] = lista_za_jedan_artikal
        return cenovnik,lista_imena
    except:
        print("Pogresan unos!")

def racun_pdv(pdv,cenovnik,lista_imena):
    pdv_artikla = 0
    ime = input("Zelite pdv za koji artikal?>>>")
    clan = cenovnik[ime]
    cena = clan[1]
    vrednost_pdv = pdv / 100
    vrednost_pdv += 1
    pdv_artikla = vrednost_pdv * cena
    print("Cena artikla je:",cena)
    print("PDV je:",pdv,"%")
    print("Vrednost artikla sa pdv-om je:",pdv_artikla)
    
def upis_u_fajl(cenovnik):
    fajl = open("cenovnik.bin", "wb")
    pickle.dump(cenovnik, fajl)
    fajl.close

def citanje_iz_fajla():
    fajl = open("cenovnik.bin", "rb")
    cenovnik = pickle.load(fajl)
    fajl.close
    return cenovnik

def ispis_cenovnika(cenovnik):
    print(cenovnik)

def main():
    cenovnik = {}
    izbor = ""
    while izbor != 0:
        try:
            izbor = int(input("""Izaberite jednu od sledecih akcija:
0 Izlaz
1 Izabir vrednosti pdv-a
2 Dodavanje artikla u cenovnik
3 Proracuna vrednosti pdv-a za artikal
4 Cuvanje u fajl
5 Citanje iz fajla
6 Ispis cenovnika na ekran\n"""))
        except ValueError:
            print("Morate uneti celobrojnu vrednost!")
        except:
            print("Morate izabrati validnu opciju!")
        if izbor == 1:
            pdv = vrednost_pdv()
        elif izbor == 2:
            cenovnik,lista_imena = dodavanje_artikala(cenovnik)
        elif izbor == 3:
            racun_pdv(pdv,cenovnik,lista_imena)
        elif izbor == 4:
            upis_u_fajl(cenovnik)
        elif izbor == 5:
            cenovnik = citanje_iz_fajla()
        elif izbor == 6:
            ispis_cenovnika(cenovnik)

main()
