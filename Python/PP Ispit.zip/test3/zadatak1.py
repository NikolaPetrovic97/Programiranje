suma = 0
brojac = 0
broj = 2
n = int(input("unesi broj:"))
while n !=0:
    suma += broj
    broj += 2
    n -= 1
print(suma)
