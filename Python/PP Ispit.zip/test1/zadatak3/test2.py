dnevnik = {'Kosta Plecevic':['Engleski:5'],'Jelena Nikolic':['Engleski:4']}
predmet = 'Engleski'
ocena = '5'
prethodno = dnevnik['Kosta Plecevic']
dnevnik['Kosta Plecevic'] = prethodno + [predmet + ":" + ocena]
student = "Kosta Plecevic"
broj = len(dnevnik[student])
print(broj)
print(dnevnik)
print(len(dnevnik['Kosta Plecevic']))
print(len(dnevnik['Jelena Nikolic']))
