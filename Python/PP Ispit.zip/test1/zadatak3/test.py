import pickle

def broj_predmeta():
    broj = int(input("Unesite koliko ce predmeta biti u denvniku>>>"))
    return broj

def dodavanje_studenta(dnevnik):
    try:
        ime_studenta = input("Unesi ime>>>")
        dnevnik[ime_studenta] = ""
        return dnevnik
    except:
        print("Unesite ime!")

def unos_ocena(dnevnik,broj_predmeta):
    student = ""
    broj_unosa = 0
    lista_studenta = []
    while broj_unosa < broj_predmeta:
        try:
            ocena = int(input("Unesi ocenu>>>"))
            predmet = input("Iz kog predmeta?>>>")
            ocena = str(ocena)
            predmet1 = [predmet + ":" + ocena]
            lista_studenta.append(predmet1)
            broj_unosa += 1
        except ValueError:
            print("Unesite celobrojnu vrednost!")
        except:
            print("Unesite ime studenta za koga je ocena!")
    while student not in dnevnik:
        student = input("Za kog studenta?>>>")
    dnevnik[student] = [lista_studenta]
    return dnevnik
def upis_u_fajl(dnevnik):
    fajl = open("dnevnik.bin", "wb")
    pickle.dump(dnevnik, fajl)
    fajl.close

def citanje_iz_fajla():
    fajl = open("dnevnik.bin", "rb")
    dnevnik = pickle.load(fajl)
    fajl.close
    return dnevnik

def ispis_dnevnika(dnevnik):
    print(dnevnik)

def main():
    dnevnik = {}
    izbor = ""
    while izbor != 0:
        try:
            izbor = int(input("""Izaberite jednu od sledecih akcija:
0 Izlaz
1 Unos broja predmeta u denvniku
2 Unos ucenika
3 Unos ocena
4 Cuvanje u fajl
5 Citanje iz fajla
6 Ispisivanje denvnika\n"""))
        except ValueError:
            print("Morate uneti celobrojnu vrednost!")
        except:
            print("Morate izabrati validnu opciju!")
        if izbor == 1:
            b_predmeta = broj_predmeta()
        elif izbor == 2:
            dnevnik = dodavanje_studenta(dnevnik)
        elif izbor == 3:
            dnevnik = unos_ocena(dnevnik,b_predmeta)
        elif izbor == 4:
            upis_u_fajl(dnevnik)
        elif izbor == 5:
            dnevnik = citanje_iz_fajla()
        elif izbor == 6:
            ispis_dnevnika(dnevnik)

main()
