import pickle

def dodavanje_artikala(katalog,lista_imena):
    lista_za_jedan_artikal =[]
    try:
        lista_za_jedan_artikal =[]
        ime_artikla = input("Unesi ime artikla>>>")
        sifra_artikla = input("Unesi sifru artikla>>>")
        broj_na_stanju_artikla = int(input("Unesi koliko ima na stanju>>>"))
        cena_artikla = float(input("Unesi cenu>>>"))
        lista_imena.append(ime_artikla)
        lista_za_jedan_artikal.append(sifra_artikla)
        lista_za_jedan_artikal.append(broj_na_stanju_artikla)
        lista_za_jedan_artikal.append(cena_artikla)
        katalog[ime_artikla] = lista_za_jedan_artikal
        return katalog,lista_imena
    except:
        print("Pogresan unos!")

def ukupna_cena(katalog,lista_imena):
    suma = 0
    for i in lista_imena:
        clan = katalog[i]
        cena = clan[2]
        suma += cena
    print(suma)

    
def upis_u_fajl(katalog):
    fajl = open("katalog.bin", "wb")
    pickle.dump(katalog, fajl)
    fajl.close

def citanje_iz_fajla():
    fajl = open("katalog.bin", "rb")
    katalog = pickle.load(fajl)
    fajl.close
    return katalog

def ispis_kataloga(katalog):
    print(katalog)

def main():
    katalog = {}
    lista_imena = []
    izbor = ""
    while izbor != 0:
        try:
            izbor = int(input("""Izaberite jednu od sledecih akcija:
0 Izlaz
1 Dodavanje artikla u katalog
2 Racunanje ukupne vrednosti svih artikala u katalogu
3 Cuvanje u fajl
4 Citanje iz fajla
5 Ispis kataloga na ekran\n"""))
        except ValueError:
            print("Morate uneti celobrojnu vrednost!")
        except:
            print("Morate izabrati validnu opciju!")
        if izbor == 1:
            katalog,lista_imena = dodavanje_artikala(katalog,lista_imena)
        elif izbor == 2:
            ukupna_cena(katalog,lista_imena)
        elif izbor == 3:
            upis_u_fajl(katalog)
        elif izbor == 4:
            katalog = citanje_iz_fajla()
        elif izbor == 5:
            ispis_kataloga(katalog)

main()
