lista_za_jedan_artikal =[]
katalog = {}
lista_imena = []
ime_artikla = ""

ime_artikla = input("Unesi ime artikla>>>")
sifra_artikla = input("Unesi sifru artikla>>>")
broj_na_stanju_artikla = int(input("Unesi koliko ima na stanju>>>"))
cena_artikla = float(input("Unesi cenu>>>"))
lista_imena.append(ime_artikla)
lista_za_jedan_artikal.append(sifra_artikla)
lista_za_jedan_artikal.append(broj_na_stanju_artikla)
lista_za_jedan_artikal.append(cena_artikla)
katalog[ime_artikla] = lista_za_jedan_artikal

suma = 0
for i in lista_imena:
    clan = katalog[i]
    cena = clan[2]
    suma += cena
clan = katalog[ime_artikla]

print(katalog['mast'])
print(suma)
